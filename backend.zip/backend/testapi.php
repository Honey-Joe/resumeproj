<?php
echo "<h2>PHP is working on BigRock!</h2>";

echo "<p>Today's date is: " . date("Y-m-d H:i:s") . "</p>";

// PHP Info button
echo "<p><a href='phpinfo.php'>View PHP Info</a></p>";
?>
