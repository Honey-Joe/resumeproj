<?php
// config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'Users');
define('DB_PASS', 'Nulr2025@00#');
define('DB_NAME', 'fwt_resume_builder');
define('SECRET_KEY', 'your_jwt_secret_key_here');
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'strong_Pass');