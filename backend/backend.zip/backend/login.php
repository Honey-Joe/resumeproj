<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

try {
    if (!$conn || $conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    $data = json_decode(file_get_contents("php://input"), true);
    $identifier = trim($data['identifier'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($identifier) || empty($password)) {
        throw new Exception("Missing credentials");
    }

    // === Try Admin Login (by username) ===
    $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement failed (admin): " . $conn->error);
    }
    $stmt->bind_param("s", $identifier);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        echo json_encode([
            'success' => true,
            'token' => 'adminsecret',
            'role' => 'admin'
        ]);
        exit;
    }

    // === Try User Login (by email) ===
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement failed (user): " . $conn->error);
    }
    $stmt->bind_param("s", $identifier);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // update last login
        $updateLogin = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        if ($updateLogin) {
            $updateLogin->bind_param("i", $user['id']);
            $updateLogin->execute();
        }

        echo json_encode([
            'success' => true,
            'token' => 'usersecret',
            'role' => 'user'
        ]);
        exit;
    }

    // === If both fail ===
    echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
    exit;

} catch (Exception $e) {
    // Log error (optional)
    error_log($e->getMessage());

    echo json_encode([
        'success' => false,
        'message' => 'An error occurred during login. Please try again later.',
        'error' => $e->getMessage() // You can remove this line in production for security
    ]);
    http_response_code(500);
    exit;
}
?>
